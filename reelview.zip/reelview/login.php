<?php
require 'db.php';
session_start();
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

$email = $conn->real_escape_string($data['email']);
$password = $data['password'];

$res = $conn->query("SELECT id, name, password FROM users WHERE email='$email'");
if ($res->num_rows == 1) {
    $user = $res->fetch_assoc();
    if (password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        echo json_encode(["success"=>true, "name"=>$user['name']]);
        exit;
    }
}
echo json_encode(["success"=>false, "msg"=>"Email atau password salah!"]);
?>