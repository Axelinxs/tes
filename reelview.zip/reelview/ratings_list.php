<?php
$movies = [
    [
        "title" => "Avengers: Endgame",
        "rating" => 4.7
    ],
    [
        "title" => "The Dark Knight",
        "rating" => 4.8
    ],
    [
        "title" => "Inception",
        "rating" => 4.6
    ],
    [
        "title" => "Parasite",
        "rating" => 4.5
    ],
    [
        "title" => "Spider-Man: No Way Home",
        "rating" => 4.3
    ],
    [
        "title" => "Dune",
        "rating" => 4.2
    ],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Rata-rata Rating Film</title>
    <style>
        body { background: #181a20; color: #e5e5e5; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .container { max-width: 500px; margin: 40px auto; padding: 20px; }
        table { width: 100%; border-collapse: collapse; background: #23242b; border-radius: 12px; overflow: hidden; }
        th, td { padding: 14px 10px; text-align: left; }
        th { background: #292b34; color: #ffd700; }
        tr:not(:last-child) td { border-bottom: 1px solid #393b44; }
        .rating { font-weight: bold; color: #ffb92a; }
    </style>
</head>
<body>
    <div class="container">
        <h2 style="color:#ffd700;margin-bottom:24px;">Daftar Rata-rata Rating Film</h2>
        <table>
            <thead>
                <tr>
                    <th>Judul Film</th>
                    <th>Rata-rata Rating</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($movies as $movie): ?>
                <tr>
                    <td><?= htmlspecialchars($movie['title']) ?></td>
                    <td class="rating"><?= number_format($movie['rating'], 1) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>