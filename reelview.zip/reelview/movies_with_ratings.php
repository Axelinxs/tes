<?php
session_start();
include 'db.php';

$movie_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Ambil data film
$stmt = $conn->prepare("SELECT * FROM movies WHERE id = ?");
$stmt->bind_param("i", $movie_id);
$stmt->execute();
$result = $stmt->get_result();
$movie = $result->fetch_assoc();
$stmt->close();

if (!$movie) {
    echo "Film tidak ditemukan.";
    exit;
}

// Ambil komentar dan rating
$stmt = $conn->prepare("SELECT c.comment, c.created_at, u.name, r.rating
                        FROM comments c
                        JOIN users u ON c.user_id = u.id
                        LEFT JOIN ratings r ON r.user_id = u.id AND r.movie_id = c.movie_id
                        WHERE c.movie_id = ? ORDER BY c.created_at DESC");
$stmt->bind_param("i", $movie_id);
$stmt->execute();
$comments = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($movie['title']) ?> - Detail</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body class="dark">
    <div class="container">
        <header>
            <div class="logo">ReelView</div>
            <div class="user-profile">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <span>Selamat datang, <?= $_SESSION['user_name'] ?? 'User' ?>!</span>
                    <a href="logout.php"><button>Keluar</button></a>
                <?php else: ?>
                    <a href="login.php"><button>Masuk</button></a>
                <?php endif; ?>
            </div>
        </header>

        <div class="movie-detail">
            <img src="<?= htmlspecialchars($movie['poster']) ?>" alt="Poster" style="max-width: 250px;">
            <h1><?= htmlspecialchars($movie['title']) ?> (<?= $movie['year'] ?>)</h1>
            <p><strong>Genre:</strong> <?= htmlspecialchars($movie['genre']) ?></p>
            <iframe width="560" height="315" src="<?= htmlspecialchars($movie['trailer']) ?>" frameborder="0" allowfullscreen></iframe>
        </div>

        <hr>

        <h2>Berikan Komentar & Rating</h2>
        <?php if (isset($_SESSION['user_id'])): ?>
            <form method="POST" action="submit_comment.php">
                <input type="hidden" name="movie_id" value="<?= $movie_id ?>">
                <textarea name="comment" placeholder="Tulis komentar Anda..." required></textarea><br>
                <label>Rating (1-5):</label>
                <input type="number" name="rating" min="1" max="5" required>
                <button type="submit">Kirim</button>
            </form>
        <?php else: ?>
            <p><a href="login.php">Login</a> untuk memberikan komentar.</p>
        <?php endif; ?>

        <hr>

        <h2>Komentar Penonton</h2>
        <?php if ($comments->num_rows > 0): ?>
            <?php while ($row = $comments->fetch_assoc()): ?>
                <div class="comment-box">
                    <strong><?= htmlspecialchars($row['name']) ?></strong>
                    <span>(<?= $row['created_at'] ?>)</span><br>
                    Rating: <?= intval($row['rating']) ?>/5
                    <p><?= nl2br(htmlspecialchars($row['comment'])) ?></p>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Belum ada komentar.</p>
        <?php endif; ?>
    </div>
</body>
</html>
