<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>ReelView - Movie Rating Platform</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        /* Tambahan agar poster proporsional */
        .poster-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 10px;
            background: #23242b;
            display: block;
        }
        .movie-poster {
            width: 100%;
            height: 300px;
            background: linear-gradient(45deg, #181a20, #23242b);
            border-radius: 10px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            position: relative;
            overflow: hidden;
            border: 2px solid #353535;
            box-shadow: 0 2px 16px 0 rgba(0,0,0,0.18);
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">ReelView</div>
            <div class="auth-buttons" id="authButtons">
                <button class="btn btn-secondary" onclick="showModal('loginModal')">Masuk</button>
                <button class="btn btn-primary" onclick="showModal('registerModal')">Daftar</button>
            </div>
            <div class="user-profile" id="userProfile">
                <span class="welcome-text" id="welcomeText">Selamat datang, User!</span>
                <button class="logout-btn" onclick="logout()">Keluar</button>
            </div>
        </header>
        <div class="search-section">
            <input type="text" class="search-box" placeholder="Cari film favorit Anda..." id="searchBox" onkeyup="searchMovies()">
        </div>
        <div class="movies-grid" id="moviesGrid"></div>
    </div>

    <!-- Login Modal -->
    <div class="modal" id="loginModal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal('loginModal')">&times;</span>
            <h2>Masuk ke ReelView</h2>
            <form onsubmit="login(event)">
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" id="loginEmail" placeholder="Masukkan email Anda" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" id="loginPassword" placeholder="Masukkan password Anda" required>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%;">Masuk</button>
            </form>
        </div>
    </div>

    <!-- Register Modal -->
    <div class="modal" id="registerModal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal('registerModal')">&times;</span>
            <h2>Daftar ke ReelView</h2>
            <form onsubmit="register(event)">
                <div class="form-group">
                    <label>Nama Lengkap</label>
                    <input type="text" id="registerName" placeholder="Masukkan nama lengkap Anda" required>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" id="registerEmail" placeholder="Masukkan email Anda" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" id="registerPassword" placeholder="Buat password Anda" required>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%;">Daftar</button>
            </form>
        </div>
    </div>

    <!-- Trailer Modal -->
    <div class="modal trailer-modal" id="trailerModal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal('trailerModal')">&times;</span>
            <h2 id="trailerTitle">Trailer Film</h2>
            <iframe class="trailer-video" id="trailerVideo" src="" frameborder="0" allowfullscreen></iframe>
            <p style="color: rgba(255,255,255,0.8); text-align: center;">
                Nikmati trailer film pilihan Anda
            </p>
        </div>
    </div>

    <script>
let allMovies = [];
let userRatings = {};
let averageRatings = {};
let currentUser = null;

// Fetch movie data
async function fetchMovies() {
    const res = await fetch('movies.php');
    allMovies = await res.json();
    displayMovies(allMovies);
}

async function fetchUserRatings() {
    const res = await fetch('get_ratings.php');
    userRatings = await res.json();
    displayMovies(allMovies);
}

async function fetchAverageRatings() {
    const res = await fetch('average_ratings.php');
    averageRatings = await res.json();
    displayMovies(allMovies);
}

function displayMovies(movies) {
    const grid = document.getElementById('moviesGrid');
    grid.innerHTML = '';
    movies.forEach(movie => {
        const userRating = userRatings[movie.id] || 0;
        const avg = averageRatings[movie.id] ? averageRatings[movie.id].avg_rating : null;
        const total = averageRatings[movie.id] ? averageRatings[movie.id].total : 0;

        const movieCard = document.createElement('div');
        movieCard.className = 'movie-card';
        movieCard.innerHTML = `
            <a href="movies_with_ratings.php?id=${movie.id}"><div class="movie-poster">
                <img src="${movie.poster}" alt="${movie.title}" class="poster-img" onerror="this.onerror=null;this.src='img/placeholder.png';">
                <div class="play-button" onclick="playTrailer(${movie.id})">
                    ▶️
                </div>
            </div></a>
            <div class="movie-title">${movie.title}</div>
            <div class="movie-info">
                <span>${movie.year} • ${movie.genre}</span>
            </div>
            <div class="rating-section">
                <div class="stars" id="stars-${movie.id}">
                    ${generateStars(movie.id, userRating)}
                </div>
                <span class="rating-value">
                    ${userRating > 0 ? userRating + '/5 (Rating Anda)' : 'Belum dinilai'}
                </span>
            </div>
            <div class="average-rating" style="margin-top:6px; font-size:0.98rem; color:#ffd700;">
                ⭐ Rata-rata: ${avg !== null ? avg + ' (' + total + ' penilai)' : 'Belum ada rating'}
            </div>
        `;
        grid.appendChild(movieCard);
    });
}

function generateStars(movieId, currentRating) {
    let starsHTML = '';
    for (let i = 1; i <= 5; i++) {
        const activeClass = i <= currentRating ? 'active' : '';
        starsHTML += `<span class="star ${activeClass}" onclick="rateMovie(${movieId}, ${i})">★</span>`;
    }
    return starsHTML;
}

async function rateMovie(movieId, rating) {
    if (!currentUser) {
        alert('Silakan login');
        showModal('loginModal');
        return;
    }
    await fetch('rate.php', {
        method: 'POST',
        body: JSON.stringify({movie_id: movieId, rating})
    });
    userRatings[movieId] = rating;
    displayMovies(allMovies);
    await fetchAverageRatings(); // Refresh rata-rata rating setelah memberi rating
    showNotification(`Anda memberikan rating ${rating}/5 untuk film ini!`);
}

function playTrailer(movieId) {
    const movie = allMovies.find(m => m.id == movieId);
    if (movie) {
        document.getElementById('trailerTitle').textContent = `Trailer: ${movie.title}`;
        document.getElementById('trailerVideo').src = movie.trailer;
        showModal('trailerModal');
    }
}

function searchMovies() {
    const searchTerm = document.getElementById('searchBox').value.toLowerCase();
    const filteredMovies = allMovies.filter(movie =>
        movie.title.toLowerCase().includes(searchTerm) ||
        movie.genre.toLowerCase().includes(searchTerm)
    );
    displayMovies(filteredMovies);
}

async function login(event) {
    event.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const res = await fetch('login.php', {
        method: 'POST',
        body: JSON.stringify({email, password})
    });
    const result = await res.json();
    if (result.success) {
        currentUser = {name: result.name};
        updateUIForLoggedInUser();
        closeModal('loginModal');
        showNotification(`Selamat datang kembali, ${result.name}!`);
        fetchUserRatings();
    } else {
        alert(result.msg);
    }
}

async function register(event) {
    event.preventDefault();
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const res = await fetch('register.php', {
        method: 'POST',
        body: JSON.stringify({name, email, password})
    });
    const result = await res.json();
    if (result.success) {
        currentUser = {name: name};
        updateUIForLoggedInUser();
        closeModal('registerModal');
        showNotification(`Selamat bergabung, ${name}!`);
        userRatings = {};
    } else {
        alert(result.msg);
    }
}

async function logout() {
    const res = await fetch('logout.php');
    const result = await res.json();
    if (result.success) {
        currentUser = null;
        userRatings = {};
        updateUIForLoggedOutUser();
        fetchMovies();
        fetchAverageRatings();
        showNotification('Anda telah berhasil keluar!');
    }
}

function updateUIForLoggedInUser() {
    document.getElementById('authButtons').style.display = 'none';
    document.getElementById('userProfile').style.display = 'flex';
    document.getElementById('welcomeText').textContent = `Selamat datang, ${currentUser.name}!`;
}

function updateUIForLoggedOutUser() {
    document.getElementById('authButtons').style.display = 'flex';
    document.getElementById('userProfile').style.display = 'none';
}

function showModal(id) {
    document.getElementById(id).style.display = 'block';
}

function closeModal(id) {
    document.getElementById(id).style.display = 'none';
    if (id === 'trailerModal') {
        document.getElementById('trailerVideo').src = '';
    }
}

function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(45deg, #4CAF50, #45a049);
        color: white;
        padding: 15px 20px;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        z-index: 2000;
        animation: slideIn 0.3s ease;
    `;
    notification.textContent = message;
    if (!document.querySelector('#notificationStyles')) {
        const style = document.createElement('style');
        style.id = 'notificationStyles';
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(style);
    }
    document.body.appendChild(notification);
    setTimeout(() => { notification.remove(); }, 3000);
}

window.onclick = function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target === modal) {
            modal.style.display = 'none';
            if (modal.id === 'trailerModal') {
                document.getElementById('trailerVideo').src = '';
            }
        }
    });
}

window.onload = () => {
    fetchMovies();
    fetchUserRatings();
    fetchAverageRatings();
}
    </script>
</body>
</html>