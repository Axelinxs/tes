<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    die("Akses ditolak. Silakan login terlebih dahulu.");
}

$user_id = $_SESSION['user_id'];
$movie_id = isset($_POST['movie_id']) ? intval($_POST['movie_id']) : 0;
$comment = trim($_POST['comment']);
$rating = isset($_POST['rating']) ? intval($_POST['rating']) : null;

if (empty($comment) || $movie_id <= 0 || $rating < 1 || $rating > 5) {
    die("Data tidak valid.");
}

// Simpan komentar
$stmt = $conn->prepare("INSERT INTO comments (movie_id, user_id, comment) VALUES (?, ?, ?)");
$stmt->bind_param("iis", $movie_id, $user_id, $comment);
$stmt->execute();
$stmt->close();

// Cek apakah user sudah pernah memberi rating
$stmt = $conn->prepare("SELECT id FROM ratings WHERE movie_id = ? AND user_id = ?");
$stmt->bind_param("ii", $movie_id, $user_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    // Update rating jika sudah ada
    $stmt->close();
    $stmt = $conn->prepare("UPDATE ratings SET rating = ? WHERE movie_id = ? AND user_id = ?");
    $stmt->bind_param("iii", $rating, $movie_id, $user_id);
    $stmt->execute();
    $stmt->close();
} else {
    // Tambah rating baru
    $stmt->close();
    $stmt = $conn->prepare("INSERT INTO ratings (movie_id, user_id, rating) VALUES (?, ?, ?)");
    $stmt->bind_param("iii", $movie_id, $user_id, $rating);
    $stmt->execute();
    $stmt->close();
}

// Kembali ke halaman detail film
header("Location: movies_with_ratings.php?id=" . $movie_id);
exit;
?>
