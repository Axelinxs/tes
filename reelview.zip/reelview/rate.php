<?php
require 'db.php';
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success"=>false, "msg"=>"Belum login"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$user_id = $_SESSION['user_id'];
$movie_id = intval($data['movie_id']);
$rating = intval($data['rating']);

$res = $conn->query("SELECT id FROM ratings WHERE user_id=$user_id AND movie_id=$movie_id");
if ($res->num_rows > 0) {
    $conn->query("UPDATE ratings SET rating=$rating WHERE user_id=$user_id AND movie_id=$movie_id");
} else {
    $conn->query("INSERT INTO ratings (user_id, movie_id, rating) VALUES ($user_id, $movie_id, $rating)");
}
echo json_encode(["success"=>true]);
?>