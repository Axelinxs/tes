<?php
require 'db.php';
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit;
}

$user_id = $_SESSION['user_id'];
$res = $conn->query("SELECT movie_id, rating FROM ratings WHERE user_id=$user_id");
$ratings = [];
while ($row = $res->fetch_assoc()) {
    $ratings[$row['movie_id']] = $row['rating'];
}
echo json_encode($ratings);
?>