<?php
require 'db.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

$name = $conn->real_escape_string($data['name']);
$email = $conn->real_escape_string($data['email']);
$password = password_hash($data['password'], PASSWORD_BCRYPT);

$res = $conn->query("SELECT id FROM users WHERE email='$email'");
if ($res->num_rows > 0) {
    echo json_encode(["success"=>false, "msg"=>"Email sudah terdaftar!"]);
    exit;
}

$conn->query("INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')");
echo json_encode(["success"=>true, "msg"=>"Berhasil daftar!"]);
?>