<?php
require 'db.php';
header('Content-Type: application/json');

// Ambil rata-rata rating untuk setiap film
$res = $conn->query("
    SELECT movie_id, AVG(rating) as avg_rating, COUNT(*) as total
    FROM ratings
    GROUP BY movie_id
");

$averages = [];
while ($row = $res->fetch_assoc()) {
    $averages[$row['movie_id']] = [
        'avg_rating' => round($row['avg_rating'], 2),
        'total' => (int)$row['total'],
    ];
}
echo json_encode($averages);
?>