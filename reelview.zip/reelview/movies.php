<?php
require 'db.php';

$res = $conn->query("SELECT * FROM movies");
$movies = [];
while($row = $res->fetch_assoc()) {
    $movies[] = $row;
}
echo json_encode($movies);
?>